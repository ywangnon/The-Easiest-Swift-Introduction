import UIKit

/*:
 
 # 가장 쉬운 Swift 입문 책
 
 - 보면서 기억할만한 것들을 따로 정리하였다.
 
 ## 1장
 
 - Swift는 애플에 의해 설계된 코코아(Mac OS X)와 코코아 터치(iOS) 프로그래밍을 위한 새로운 프로그래밍 언어
 
 ## 2장
 
 ### 정수 리터럴
 
 - 2진수: 0b
 
 - 8진수: 0o
 
 - 16진수: 0x
 
 ### 부동 소수점
 
 - Float: 32bit
 
 - Double: 64bit
 
 ### 부동 소수점 리터럴
 
 10의 제곱: E(e)로 표현
 
 - 10^2: E2
 
 - 10^(-2): E-2
 
 16진수 2의 제곱: p
 
 - 0xFp2: 15 * (2^2)
 
 ### 튜플
 
 - 순서있음
 
 - 모두 같은 자료형일 필요 없음
 
 ### 열거형 함수
 
 */

enum DeviceType {
    case Phone (Int, String)
    case Tablet(String)
    var info: String {
        switch self {
        case let .Phone(type, model):
            return "\(type) - " + model
        case let .Tablet(model):
            return model
        }
    }
}

var d1 = DeviceType.Phone(1, "iPhone")
d1.info

/*:
 
 ### 원시값 자동 증가
 
 - 중간에 다른값을 넣으면 그 수부터 다시 증가
 
 */

enum heroCharacters: Int {
    case SuperMan = 1
    case Batman
    case Wonderwoman
    case Spiderman = 9
    case IronMan
    case CaptainAmerica
}

var h = heroCharacters.Wonderwoman
print(h.rawValue)

h = heroCharacters.IronMan
print(h.rawValue)

/*:
 
 ## 5장
 
 ### 가변 매개 변수
 
 - ...: 가변적인 수의 인자를 받을 수 있는 매개변수
 
 - 함수에서 모든 매개 변수는 상수
 
 */

func average(nums: Int...) -> Float {
    var sum: Float = 0

    for num in nums {
        sum += Float(num)
    }

    return sum/Float(nums.count)
}

print(average(nums: 1,2,3))
print(average(nums: 1,2,3,4))
print(average(nums: 1,2,3,4,5,6))

/*:
 
 ### In-Out 매개 변수
 
 - 함수 안에서 변경된 내용이 지속되는 매개 변수
 
 #### 주의사항
 
 - 매개변수로 변수를 전달. 상수 금지
 
 - 값의 변경 가능을 표현하기 위해 전달하는 변수앞에 &붙임
 
 - 기본값 금지
 
 */

func fullName(name: inout String, withTitle title: String) {
    name = title + " " + name
}

var myName = "James"
fullName(name: &myName, withTitle: "Mr.")
print(myName)

/*:
 
 ## 6장
 
 ### 딕셔너리
 
 - 순서 x
 
 - 키로 접근
 
 - 반환값이 없을 수도 있으므로 옵셔널
 
 */


var ranking = [
    1:"Gold",
    2:"Silver",
    3:"Bronze"
]

print(ranking[1])

/*:
 
 ## 7장
 
 ### Switch
 
 - 각 case는 반드시 하나 이상의 실행문 가짐. 주석은 안됨.
 
 - fallthrough 동작의 구현은 명시적으로 키워드 사용
 
 - 튜플 매칭시 일치하는 값을 임시 변수나 상수에 값 바인딩 해줌
 
 ### Where
 
 - where로 조건 검사 가능
 
 */

var score = (70, 60)

switch score {
case let (math, science) where math > 80 && science > 80:
    print("Good!")
case (50...100, let science):
    if science<50 {
        print("science failed")
    } else {
        print("science passed")
    }
case (let math, 50...100):
    if math<50 {
        print("math failed")
    } else {
        print("math passed")
    }
default:
    print("failed")
}

/*:
 
 ### for-in 루프
 
 - 배열, 딕셔너리, 문자열 직접 넣어서 반복 가능
 
 ### While 루프
 
 - 조건이 true인 한 반복 수행
 
 ### 제어 이동문
 
 - break: 루프 끝으로 이동
 
 - continue: 나머지 문장을 실행하지 않고 다음 반복 진행
 
 - outerLoop: 라벨ㅇ르 붙여 명시적으로 빠져나오려는 While 루프 지정
 
 */
